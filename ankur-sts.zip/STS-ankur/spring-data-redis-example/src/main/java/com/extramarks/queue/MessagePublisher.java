package com.extramarks.queue;

public interface MessagePublisher {

    void publish(final String message);
}
